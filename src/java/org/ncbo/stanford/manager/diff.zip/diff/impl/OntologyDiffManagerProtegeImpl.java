
package org.ncbo.stanford.manager.diff.impl;
/**
 * Provides the functionality to compare two Protege ontologies
 * 
 * @author Natasha Noy
 * 
 */
import java.util.*;

import org.ncbo.stanford.bean.*;
import org.ncbo.stanford.domain.custom.dao.*;
import org.ncbo.stanford.domain.custom.entity.*;
import org.ncbo.stanford.enumeration.*;
import org.ncbo.stanford.manager.*;
import org.ncbo.stanford.manager.diff.*;
import org.ncbo.stanford.service.ontology.*;

import edu.stanford.smi.protege.model.*;
import edu.stanford.smi.protegex.prompt.promptDiff.*;

public class OntologyDiffManagerProtegeImpl extends
		AbstractOntologyManagerProtege implements OntologyDiffManager {

	private OntologyService ontologyService;
	private CustomNcboOntologyVersionDAO ncboOntologyVersionDAO;

	/**
	 * Creates a diff between the ontology that has just been loaded and its
	 * previous version(if one exists in BioPortal).
	 * Save the diff in a file
	 * 
	 * @param ontologyBean
	 *	 
	 * @throws Exception
	 */

	public void createDiffForTwoLatestVersions (Integer ontologyId) throws Exception {
		List<OntologyBean> allVersions = ontologyService.findAllOntologyVersionsByOntologyId(ontologyId);

		// get a list of version ids, filtering out ontologies that are not active
		// (want to compare only active ontologies
		List<Integer> versionIds = new ArrayList<Integer> (allVersions.size());
		
		for (OntologyBean ontologyVersion : allVersions) {
			if (ontologyVersion.getStatusId() == StatusEnum.STATUS_READY.getStatus()) {
				versionIds.add(ontologyVersion.getId());
			}
		}
		
		// there are fewer than two active versions -- nothing to compare
		if (versionIds.size() < 2) return;
		
		Collections.sort (versionIds);
		
		Integer newVersionId = versionIds.get(0); // latest version
		Integer oldVersionId = versionIds.get(1); // previous version
		
		VNcboOntology newVersion = ncboOntologyVersionDAO.findOntologyVersion(newVersionId);
		VNcboOntology oldVersion = ncboOntologyVersionDAO.findOntologyVersion(oldVersionId);
		
		createDiff (oldVersion, newVersion);
		
		
	}

	/** 
	 * Creates a diff between two ontology versions
	 * 
	 * @param ontologyVersionOld, ontologyVersionNew
	 * 
	 * @throws Exception
	 */
	
	public void createDiff (VNcboOntology ontologyVersionOld,
			VNcboOntology ontologyVersionNew) throws Exception {

		System.out.println("HERE");
		
		KnowledgeBase oldKb = getKnowledgeBase (ontologyVersionOld);
		KnowledgeBase newKb = getKnowledgeBase (ontologyVersionNew);
	
		PromptDiff promptDiff = new PromptDiff ();
		promptDiff.runDiff (oldKb, newKb);
		promptDiff.getResultsTable().printResultsTable();
	}

	public DiffBean getDiff(VNcboOntology ontologyVersionOld,
			VNcboOntology ontologyVersionNew) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

}
