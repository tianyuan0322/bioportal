/*
 * Contributor(s): Natasha Noy noy@smi.stanford.edu
 */
package org.ncbo.stanford.manager.diff.impl;

import org.ncbo.stanford.bean.*;
import org.ncbo.stanford.domain.custom.entity.*;
import org.ncbo.stanford.manager.*;
import org.ncbo.stanford.manager.diff.*;

public class OntologyDiffManagerLexGridImpl extends		
	AbstractOntologyManagerLexGrid implements OntologyDiffManager {

	public void createDiff(VNcboOntology ontologyVersionOld,
			VNcboOntology ontologyVersionNew) throws Exception {
		// TODO Auto-generated method stub

	}

	public void createDiffForTwoLatestVersions(Integer ontologyId)
			throws Exception {
		// TODO Auto-generated method stub

	}

	public DiffBean getDiff(VNcboOntology ontologyVersionOld,
			VNcboOntology ontologyVersionNew) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

}
