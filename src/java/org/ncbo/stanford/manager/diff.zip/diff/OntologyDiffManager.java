package org.ncbo.stanford.manager.diff;

/**
 * An interface designed to provide an abstraction layer to ontology diff 
 * operation. The service layer will consume this interface instead of directly
 * calling a specific implementation (i.e. LexGrid, Protege etc.). This
 * interface should be used by internal services and should not be exposed to
 * upper layers.
 * 
 * @author Natasha Noy
 * 
 */

import org.ncbo.stanford.bean.*;
import org.ncbo.stanford.domain.custom.entity.*;

public interface OntologyDiffManager {
	public void createDiff (VNcboOntology ontologyVersionOld, VNcboOntology ontologyVersionNew)
	throws Exception;

	public void createDiffForTwoLatestVersions (Integer ontologyId)
	throws Exception;

	public DiffBean getDiff (VNcboOntology ontologyVersionOld, VNcboOntology ontologyVersionNew)
	throws Exception;
	
}
